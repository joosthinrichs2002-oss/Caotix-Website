CAOTIX Press Photo Kit — 9 curated high-resolution images.
Rock am Pferdemarkt 2026. No photographer credit required.
