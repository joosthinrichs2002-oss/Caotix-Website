CAOTIX EPK

01_Press_Text  - press text (PDF + TXT)
02_Logos       - logo assets (PNG + SVG)
03_Production  - stage plot and technical rider
04_Press_Photos- 6 curated high-resolution press/member photos
05_Live_Photos - 3 curated high-resolution live/atmosphere photos

Photo selection: Rock am Pferdemarkt 2026. No photographer credit required.
