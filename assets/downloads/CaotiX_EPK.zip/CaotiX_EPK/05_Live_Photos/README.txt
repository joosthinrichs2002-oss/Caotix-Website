Curated CAOTIX live photos. High-resolution originals from Rock am Pferdemarkt 2026.
No photographer credit required.
